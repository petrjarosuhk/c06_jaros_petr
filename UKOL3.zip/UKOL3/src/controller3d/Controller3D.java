package controller3d;

import curves.BezierCubic;
import curves.CoonsCubic;
import curves.FergusonCubic;
import curves.Grid;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.image.BufferedImage;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JSlider;
import javax.swing.JToolBar;
import model3d.Cube;
import model3d.Octahedron;
import model3d.Pyramid;
import model3d.Scene;
import model3d.Solid;
import rasterize.Raster;
import render.Renderer;
import render.WireFrameRenderer;
import transforms.Camera;
import transforms.Mat4;
import transforms.Mat4Identity;
import transforms.Mat4OrthoRH;
import transforms.Mat4PerspRH;
import transforms.Mat4RotX;
import transforms.Mat4RotY;
import transforms.Mat4RotZ;
import transforms.Mat4Scale;
import transforms.Mat4Transl;
import transforms.Vec3D;
import view.Panel;

public class Controller3D {
    private final Renderer renderer;
    private final Raster raster;
    private final JToolBar toolBar;
    private final Panel panel;
    double rotation;
    private double zNear = 0.5D;
    private double zFar = 50.0D;
    private int xClicked;
    private int yClicked;
    private JButton buttonApply;
    private JButton buttonReset;
    private String selectedAxis;
    private JComboBox cb;
    private Scene mainScene;
    private Mat4 model;
    private Mat4 view;
    private Mat4 projection;
    private Camera camera;
    private double movementSpeed = 1;
    private double rotationalSpeed = 0.5;
    private JSlider sliderPosition;
    private JSlider sliderRotation;
    private JSlider sliderSize;
    private int position;
    private int size;
    private double coefficientHladkost = 0.05D;

    //kontruktor pro zavedení panelu
    public Controller3D(Panel panel) {
        this.raster = panel.getRaster();
        this.panel = panel;

        this.toolBar = panel.getToolBarMenu();
        this.buttonApply = panel.getBtnApply();
        this.buttonReset = panel.getBtnReset();
        this.sliderPosition = panel.getSliderPosition();
        this.sliderRotation = panel.getSliderRotation();
        this.sliderSize = panel.getSliderSize();
        this.mainScene = new Scene();
        this.model = new Mat4Identity();
        this.camera = (new Camera()).withPosition(new Vec3D(7.6, 7.5, 2.5)).withAzimuth(3.89).withZenith(-0.25);
        this.view = this.camera.getViewMatrix();
        this.renderer = new WireFrameRenderer(this.raster, this.model, this.view, this.projection);
        this.initSolids();
        this.cb = panel.getCb();
        this.renderer.setObjectToTransform((Solid)this.mainScene.getSolids().get(4));
        this.initSliderValues();
        this.checkCombobox();
        this.calculateTransformation();
        this.initListeners(panel);
        this.repaint();
    }

    //metoda pro získání hodnot ze Sliderů
    private void initSliderValues() {
        this.size = this.sliderSize.getValue();
        this.rotation = (double)this.sliderRotation.getValue();
        this.position = this.sliderPosition.getValue();
    }

    //metoda pro inicilizaci Solidů
    private void initSolids() {
        this.mainScene = new Scene();
        if (this.panel.getCboxCube().isSelected()) {
            this.mainScene.addSolid(new Cube());
        }

        if (this.panel.getCboxPyramid().isSelected()) {
            this.mainScene.addSolid(new Pyramid());
        }

        if (this.panel.getCboxOctahedron().isSelected()) {
            this.mainScene.addSolid(new Octahedron());
        }

        if (this.panel.getRbnPerspective().isSelected()) {
            this.projection = new Mat4PerspRH(1.0471975511965976D, (double)((float)this.raster.getHeight() / (float)this.raster.getWidth()), this.zNear, this.zFar);
        } else {
            this.projection = new Mat4OrthoRH(20.0D, 15.0D, 0.5D, 50.0D);
        }

        if (this.panel.getCboxCurve().isSelected()) {
            if (this.panel.getRbnCoons().isSelected()) {
                this.mainScene.addSolid(new CoonsCubic(this.coefficientHladkost));
            } else if (this.panel.getRbnBezier().isSelected()) {
                this.mainScene.addSolid(new BezierCubic(this.coefficientHladkost));
                this.mainScene.addSolid(new Grid(this.coefficientHladkost));
            } else {
                this.mainScene.addSolid(new FergusonCubic(this.coefficientHladkost));
            }
        }

    }

    //metoda pro "refresh" framu
    private void repaint() {
        this.view = this.camera.getViewMatrix();
        this.raster.clear();
        this.renderer.setModel(this.model);
        this.renderer.setView(this.view);
        this.renderer.setProjection(this.projection);
        this.renderer.draw(this.mainScene);
        this.drawTextOnScreen(this.raster.getBufferedImage());
    }

    public void apply() {
        this.initSolids();
        this.repaint();
    }

    //metoda pro zavedení listenerů na základě klávesnic nebo myší
    private void initListeners(final Panel panel) {
        this.buttonApply.addActionListener((e) -> {
            this.apply();
        });
        this.buttonReset.addActionListener((e) -> {
            this.reset();
        });
        panel.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                controller3d.Controller3D.this.cameraMovements(e);
                controller3d.Controller3D.this.selectObject(e);
                controller3d.Controller3D.this.repaint();
            }
        });
        panel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                controller3d.Controller3D.this.xClicked = e.getX();
                controller3d.Controller3D.this.yClicked = e.getY();
            }
        });
        panel.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                int deltaX = controller3d.Controller3D.this.xClicked - e.getX();
                int deltaY = controller3d.Controller3D.this.yClicked - e.getY();
                double azimuth = 3.141592653589793D * (double)deltaX / (double) controller3d.Controller3D.this.raster.getWidth();
                double zenith = 3.141592653589793D * (double)deltaY / (double) controller3d.Controller3D.this.raster.getHeight();
                if (zenith > 90.0D) {
                    zenith = 90.0D;
                } else if (zenith < -90.0D) {
                    zenith = -90.0D;
                }

                controller3d.Controller3D.this.camera = controller3d.Controller3D.this.camera.addAzimuth(azimuth);
                controller3d.Controller3D.this.camera = controller3d.Controller3D.this.camera.addZenith(zenith);
                controller3d.Controller3D.this.repaint();
                controller3d.Controller3D.this.xClicked = e.getX();
                controller3d.Controller3D.this.yClicked = e.getY();
            }
        });
        panel.addMouseWheelListener(new MouseAdapter() {
            public void mouseWheelMoved(MouseWheelEvent e) {
                if (e.getWheelRotation() > 0) {
                    controller3d.Controller3D.this.camera = controller3d.Controller3D.this.camera.backward(controller3d.Controller3D.this.movementSpeed);
                } else {
                    controller3d.Controller3D.this.camera = controller3d.Controller3D.this.camera.forward(controller3d.Controller3D.this.movementSpeed);
                }

                controller3d.Controller3D.this.repaint();
            }
        });
        panel.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                panel.grabFocus();
            }
        });
        this.sliderPosition.addChangeListener((e) -> {
            this.position = this.sliderPosition.getValue();
            this.calculateTransformation();
        });
        this.sliderSize.addChangeListener((e) -> {
            this.size = this.sliderSize.getValue();
            this.calculateTransformation();
        });
        this.sliderRotation.addChangeListener((e) -> {
            int degrees = this.sliderRotation.getValue();
            this.rotation = Math.toRadians((double)degrees);
            this.calculateTransformation();
        });
        this.cb.addActionListener((e) -> {
            this.checkCombobox();
        });
    }

    //metoda pro výběr jestli se má transformovat pomocí osy x,y nebo z
    private void checkCombobox() {
        if (this.cb.getSelectedIndex() == 0) {
            this.selectedAxis = "x";
        } else if (this.cb.getSelectedIndex() == 1) {
            this.selectedAxis = "y";
        } else if (this.cb.getSelectedIndex() == 2) {
            this.selectedAxis = "z";
        }

    }

    //metoda, která vyresetuje view a transformaci
    private void reset() {
        this.model = new Mat4Identity();
        this.camera = (new Camera()).withPosition(new Vec3D(7.6, 7.5, 2.5)).withAzimuth(3.89).withZenith(-0.25);
        this.view = this.camera.getViewMatrix();
        this.renderer.setMatTransformObjects(new Mat4Identity());
        this.sliderRotation.setValue(0);
        this.sliderSize.setValue(1);
        this.sliderPosition.setValue(0);
        this.repaint();
        this.coefficientHladkost = 0.05D;
    }

    //metoda pro pohyb kamery
    private void cameraMovements(KeyEvent e) {
        switch(e.getKeyCode()) {
            case 8:
                this.reset();
                break;
            case 10:
                this.apply();
                break;
            case 37:
                this.camera = this.camera.addAzimuth(-this.rotationalSpeed);
                break;
            case 38:
                this.camera = this.camera.addZenith(this.rotationalSpeed);
                break;
            case 39:
                this.camera = this.camera.addAzimuth(this.rotationalSpeed);
                break;
            case 40:
                this.camera = this.camera.addZenith(-this.rotationalSpeed);
                break;
            case 45:
            case 109:
                if (this.coefficientHladkost < 1.0D) {
                    this.coefficientHladkost += 0.01D;
                    this.apply();
                }
                break;
            case 65:
                this.camera = this.camera.left(this.movementSpeed);
                break;
            case 68:
                this.camera = this.camera.right(this.movementSpeed);
                break;
            case 69:
                this.camera = this.camera.up(this.movementSpeed);
                break;
            case 81:
                this.camera = this.camera.down(this.movementSpeed);
                break;
            case 83:
                this.camera = this.camera.backward(this.movementSpeed);
                break;
            case 87:
                this.camera = this.camera.forward(this.movementSpeed);
                break;
            case 107:
            case 521:
                if (this.coefficientHladkost > 0.01D) {
                    this.coefficientHladkost -= 0.01D;
                    this.apply();
                }
        }

    }

    //metoda, která vybere co se má dělat s daným objektem
    private void selectObject(KeyEvent e) {
        int index;
        index = 4;
        int i;
        label57:
        switch(e.getKeyCode()) {
            case 67:
                i = 3;

                while(true) {
                    if (i >= this.mainScene.getSolids().size() - 1) {
                        break label57;
                    }

                    if (((Solid)this.mainScene.getSolids().get(i)).getName().equals("curve")) {
                        index = i;
                        break label57;
                    }

                    ++i;
                }
            case 75:
                i = 3;

                while(true) {
                    if (i >= this.mainScene.getSolids().size() - 1) {
                        break label57;
                    }

                    if (((Solid)this.mainScene.getSolids().get(i)).getName().equals("cube")) {
                        index = i;
                        break label57;
                    }

                    ++i;
                }
            case 79:
                i = 3;

                while(true) {
                    if (i >= this.mainScene.getSolids().size() - 1) {
                        break label57;
                    }

                    if (((Solid)this.mainScene.getSolids().get(i)).getName().equals("octahedron")) {
                        index = i;
                        break label57;
                    }

                    ++i;
                }
            case 80:
                for(i = 3; i < this.mainScene.getSolids().size() - 1; ++i) {
                    if (((Solid)this.mainScene.getSolids().get(i)).getName().equals("pyramid")) {
                        index = i;
                        break;
                    }
                }
        }

        this.renderer.setObjectToTransform((Solid)this.mainScene.getSolids().get(index));
    }

    //metoda, která vypočíta transformaci
    private void calculateTransformation() {
        Mat4 transformationMatrix = new Mat4Identity();
        String var2 = this.selectedAxis;
        byte var3 = -1;
        switch(var2.hashCode()) {
            case 120:
                if (var2.equals("x")) {
                    var3 = 0;
                }
                break;
            case 121:
                if (var2.equals("y")) {
                    var3 = 1;
                }
                break;
            case 122:
                if (var2.equals("z")) {
                    var3 = 2;
                }
        }

        Mat4Scale scalingMatrix;
        Mat4Transl translationMatrix;
        switch(var3) {
            case 0:
                scalingMatrix = new Mat4Scale((double)this.size, 1.0D, 1.0D);
                Mat4RotX rotationMatrix = new Mat4RotX(this.rotation);
                translationMatrix = new Mat4Transl((double)this.position, 0.0D, 0.0D);
                transformationMatrix = scalingMatrix.mul(rotationMatrix).mul(translationMatrix);
                break;
            case 1:
                scalingMatrix = new Mat4Scale(1.0D, (double)this.size, 1.0D);
                Mat4RotY rotationMatrix2 = new Mat4RotY(this.rotation);
                translationMatrix = new Mat4Transl(0.0D, (double)this.position, 0.0D);
                transformationMatrix = scalingMatrix.mul(rotationMatrix2).mul(translationMatrix);
                break;
            case 2:
                scalingMatrix = new Mat4Scale(1.0D, 1.0D, (double)this.size);
                Mat4RotZ rotationMatrix3 = new Mat4RotZ(this.rotation);
                translationMatrix = new Mat4Transl(0.0D, 0.0D, (double)this.position);
                transformationMatrix = scalingMatrix.mul(rotationMatrix3).mul(translationMatrix);
        }

        this.renderer.setMatTransformObjects((Mat4)transformationMatrix);
        this.repaint();
    }

    public void drawTextOnScreen(BufferedImage image) {
        Graphics g = image.getGraphics();
        g.setColor(Color.WHITE);

        g.drawString(String.format("Hladkost křivky editujte pomocí + a -) %.2f ", this.coefficientHladkost), 30, 360);
        g.drawString("Osa červená = X, Osa, Osa zelená = Y, Osa modrá = Z ", 30, 380);
        g.drawString("Vybraný objekt pro translaci:", 30, 400);
        g.setColor(Color.orange);
        g.drawString(this.renderer.getObjectToTransform().getName().toUpperCase(), 30, 420);
        g.setColor(Color.WHITE);

        g.drawString("Jak Ovládat?:", 30, 460);
        g.drawString("Pro transforamci objektů použijte sliders níže", 30, 480);

        g.drawString("Vyberte: K=Krychle; C=Křivka; P=Pyramida; O=Octahedron", 30, 500);
        g.drawString("Pohybujte kamerou použitím klávsnice W;A;S;D,myší a šipkami. Zoom pomocí kolečka myši.", 30, 520);
        g.drawString("Reset pomocí backspace view + transformaci", 30, 560);
        g.drawString("Translace " + this.selectedAxis + " :" + this.sliderPosition.getValue(), 670, 400);
        g.drawString("Scaling " + this.selectedAxis + " :" + this.sliderSize.getValue(), 670, 420);
        g.drawString("Rotace " + this.selectedAxis + " :" + this.sliderRotation.getValue() + "°", 670, 440);
        g.drawString("Úmístění kamery: " + this.camera.getPosition(), 580, 480);
        g.drawString("Směr kamery: " + this.view.getRow(1).ignoreW(), 580, 500);
        g.drawString("Úhel kamery: " + this.view.getRow(2).ignoreW(), 580, 520);
        g.drawString("Azimuth: " + this.camera.getAzimuth(), 580, 540);
        g.drawString("Zenith: " + this.camera.getZenith(), 580, 560);

    }
}
