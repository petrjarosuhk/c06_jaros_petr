package model3d;
import transforms.Point3D;
/*
*
* Třída pro vytvoření lines x, y a z neboli axis
*
* */



public class Axis extends Solid {
    private Point3D origin;
    private Point3D otherEndPoint;


    public Axis(String axis) {
        this.name = "axis";
        this.origin = new Point3D(0.0D, 0.0D, 0.0D);
        if (axis.toLowerCase().equals("x") || axis.toLowerCase().equals("y") || axis.toLowerCase().equals("z")) {
            if (axis.toLowerCase().equals("x")) {
                this.otherEndPoint = new Point3D(5.0D, 0.0D, 0.0D);
                this.setColor(16711680);
            } else if (axis.toLowerCase().equals("y")) {
                this.otherEndPoint = new Point3D(0.0D, 5.0D, 0.0D);
                this.setColor(65280);
            } else if (axis.toLowerCase().equals("z")) {
                this.otherEndPoint = new Point3D(0.0D, 0.0D, 5.0D);
                this.setColor(255);
            }

            this.vertexBuffer.add(this.origin);
            this.vertexBuffer.add(this.otherEndPoint);
            this.indexBuffer.add(0);
            this.indexBuffer.add(1);
        }

    }
}
