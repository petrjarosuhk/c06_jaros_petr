package model3d;


import java.awt.Color;
import transforms.Point3D;

/*
*
* Třída pro vytvoření pyramidy
*
* */

public class Pyramid extends Solid {

    //konstruktor pro vytvoření pyramidy
    public Pyramid() {
        this.name = "pyramid";
        this.color = Color.LIGHT_GRAY.getRGB();
        this.vertexBuffer.add(new Point3D(0.0D, 0.0D, 2.0D));
        this.vertexBuffer.add(new Point3D(1.0D, 1.0D, -1.0D));
        this.vertexBuffer.add(new Point3D(1.0D, -1.0D, -1.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, -1.0D, -1.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, 1.0D, -1.0D));
        this.addIndices(new Integer[]{1, 2, 2, 3, 3, 4, 4, 1});
        this.addIndices(new Integer[]{0, 1, 0, 2, 0, 3, 0, 4});
    }
}
