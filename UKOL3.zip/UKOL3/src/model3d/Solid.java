package model3d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import transforms.Point3D;

/*
*
* Základní třída pro ukládání vertex hodnot a index hodnot z této třídy se dědí
*
* */


public abstract class Solid {
    protected final List<Point3D> vertexBuffer = new ArrayList();
    protected final List<Integer> indexBuffer = new ArrayList();
    protected int color = 16777215;
    protected String name = "unnamed";
    private boolean isAxis = false;

    public Solid() {
    }

    public final void addIndices(Integer[] indices) {
        this.indexBuffer.addAll(Arrays.asList(indices));
    }

    public int getColor() {
        return this.color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public List<Point3D> getVertexBuffer() {
        return this.vertexBuffer;
    }

    public List<Integer> getIndexBuffer() {
        return this.indexBuffer;
    }

    public boolean isAxis() {
        return this.isAxis;
    }

    public void setAxis(boolean axis) {
        this.isAxis = axis;
    }

    public String getName() {
        return this.name;
    }
}
