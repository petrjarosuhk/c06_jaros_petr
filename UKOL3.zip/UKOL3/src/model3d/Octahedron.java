package model3d;

import transforms.Point3D;

/*
*
* Třída pro vytvoření Octahedron
*
* */

public class Octahedron extends Solid {

    //konstruktor pro vytvoření octahedronu
    public Octahedron() {
        this.color = 16776960;
        this.name = "octahedron";
        this.vertexBuffer.add(new Point3D(0.0D, 0.0D, 1.0D));
        this.vertexBuffer.add(new Point3D(1.0D, 1.0D, 0.0D));
        this.vertexBuffer.add(new Point3D(1.0D, -1.0D, 0.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, -1.0D, 0.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, 1.0D, 0.0D));
        this.vertexBuffer.add(new Point3D(0.0D, 0.0D, -1.0D));
        this.addIndices(new Integer[]{1, 2, 2, 3, 3, 4, 4, 1});
        this.addIndices(new Integer[]{0, 1, 0, 2, 0, 3, 0, 4});
        this.addIndices(new Integer[]{5, 1, 5, 2, 5, 3, 5, 4});

    }
}
