package model3d;

import java.awt.Color;

import transforms.Point3D;

/*
*
* Třída pro vytvoření krychle - Cube
*
* */


public class Cube extends Solid {

    //konstruktor pro vytvoření krychle
    public Cube() {
        this.color = Color.WHITE.getRGB();
        this.name = "cube";
        this.vertexBuffer.add(new Point3D(1.0D, 1.0D, 1.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, 1.0D, 1.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, -1.0D, 1.0D));
        this.vertexBuffer.add(new Point3D(1.0D, -1.0D, 1.0D));
        this.vertexBuffer.add(new Point3D(1.0D, 1.0D, -1.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, 1.0D, -1.0D));
        this.vertexBuffer.add(new Point3D(-1.0D, -1.0D, -1.0D));
        this.vertexBuffer.add(new Point3D(1.0D, -1.0D, -1.0D));
        this.addIndices(new Integer[]{0, 1, 1, 2, 2, 3, 3, 0});
        this.addIndices(new Integer[]{4, 5, 5, 6, 6, 7, 7, 4});
        this.addIndices(new Integer[]{0, 4, 1, 5, 2, 6, 3, 7});

    }
}