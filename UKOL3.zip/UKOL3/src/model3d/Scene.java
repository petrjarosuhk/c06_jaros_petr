package model3d;

import java.util.ArrayList;
import java.util.List;
/*
*
* Třída pro vytvoření scény pomocí axis x,y a z
*
* */


public class Scene {
    Axis xAxis = new Axis("x");
    Axis yAxis = new Axis("y");
    Axis zAxis = new Axis("z");
    private List<model3d.Solid> solids = new ArrayList();

    public Scene() {
        this.xAxis.setAxis(true);
        this.yAxis.setAxis(true);
        this.zAxis.setAxis(true);
        this.solids.add(this.xAxis);
        this.solids.add(this.yAxis);
        this.solids.add(this.zAxis);
    }

    public void addSolid(model3d.Solid solid) {
        this.solids.add(solid);
    }

    public List<model3d.Solid> getSolids() {
        return this.solids;
    }

    public void setSolids(List<Solid> solids) {
        this.solids = solids;
    }
}