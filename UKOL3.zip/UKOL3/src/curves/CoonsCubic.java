package curves;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import model3d.Solid;
import transforms.Cubic;
import transforms.Point3D;

/*
*
* Třída pro vytvoření Coons curve
*
* */

public class CoonsCubic extends Solid {
    public CoonsCubic(double increment) {
        this.color = Color.PINK.getRGB();
        this.name = "curve";
        List<Cubic> cubics = new ArrayList();
        Point3D p1 = new Point3D(1.0D, 1.0D, 1.0D);
        Point3D p2 = new Point3D(0.0D, 2.0D, 2.0D);
        Cubic coonsCubic1 = new Cubic(Cubic.COONS, p1, p1, p1, p2);
        cubics.add(coonsCubic1);
        Point3D p3 = new Point3D(2.0D, -1.0D, 0.0D);
        cubics.add(new Cubic(Cubic.COONS, p1, p1, p2, p3));
        Point3D p4 = new Point3D(-1.0D, -1.0D, -1.0D);
        Cubic coonsCubic3 = new Cubic(Cubic.COONS, p1, p2, p3, p4);
        cubics.add(coonsCubic3);
        Point3D p5 = new Point3D(-1.0D, -1.0D, -1.0D);
        Cubic coonsCubic4 = new Cubic(Cubic.COONS, p2, p3, p4, p5);
        cubics.add(coonsCubic4);
        Cubic coonsCubic5 = new Cubic(Cubic.COONS, p3, p4, p5, p5);
        cubics.add(coonsCubic5);
        cubics.add(new Cubic(Cubic.COONS, p4, p5, p5, p5));
        Iterator var13 = cubics.iterator();

        while(var13.hasNext()) {
            Cubic c = (Cubic)var13.next();
            double lastParameterValue = 0.0D;

            for(double t = 0.0D; t <= 1.0D; t += increment) {
                Point3D computed = c.compute(t);
                this.vertexBuffer.add(computed);
                lastParameterValue = t;
            }

            if (lastParameterValue != 1.0D) {
                this.vertexBuffer.add(c.compute(1.0D));
            }

            for(int i = 1; i < this.getVertexBuffer().size(); ++i) {
                this.indexBuffer.add(i - 1);
                this.indexBuffer.add(i);
            }
        }

    }
}
