package curves;

import model3d.Solid;
import transforms.Bicubic;
import transforms.Mat4;
import transforms.Point3D;

/*
*
* Třída pro vytvoření Gridu
*
* */


public class Grid extends Solid {
    Mat4 BEZIER = new Mat4(new double[]{-1.0D, 3.0D, -3.0D, 1.0D, 3.0D, -6.0D, 3.0D, 0.0D, -3.0D, 3.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D});

    public Grid(double increment) {
        this.color = 3407805;
        Bicubic bezierBicubic = new Bicubic(this.BEZIER, new Point3D(-1.0D, 5.0D, 4.0D), new Point3D(-1.0D, 3.0D, 2.0D), new Point3D(-1.0D, 2.0D, 7.0D), new Point3D(-1.0D, 2.0D, 4.0D), new Point3D(0.0D, 4.0D, 3.0D), new Point3D(0.0D, 2.0D, 1.0D), new Point3D(0.0D, 3.0D, 4.0D), new Point3D(0.0D, 2.0D, 2.0D), new Point3D(1.0D, 5.0D, 4.0D), new Point3D(1.0D, 3.0D, 2.0D), new Point3D(1.0D, 2.0D, 7.0D), new Point3D(1.0D, 2.0D, 4.0D), new Point3D(2.0D, 5.0D, 4.0D), new Point3D(2.0D, 3.0D, 2.0D), new Point3D(2.0D, 2.0D, 7.0D), new Point3D(2.0D, 2.0D, 4.0D));
        int numRows = 0;

        for(double u = 0.0D; u < 1.0D; u += increment) {
            ++numRows;

            for(double v = 0.0D; v < 1.0D; v += increment) {
                this.vertexBuffer.add(bezierBicubic.compute(u, v));
            }
        }

        //přidávání hodnot pomocí for cyklu do indexBuffer
        for(int rowNumber = 0; rowNumber < numRows; ++rowNumber) {
            for(int columnNumber = 0; columnNumber < numRows; ++columnNumber) {
                if (rowNumber < numRows - 1) {
                    this.indexBuffer.add(rowNumber * numRows + columnNumber);
                    this.indexBuffer.add((rowNumber + 1) * numRows + columnNumber);
                }

                if (columnNumber < numRows - 1) {
                    this.indexBuffer.add(rowNumber * numRows + columnNumber);
                    this.indexBuffer.add(rowNumber * numRows + columnNumber + 1);
                }
            }
        }

    }
}