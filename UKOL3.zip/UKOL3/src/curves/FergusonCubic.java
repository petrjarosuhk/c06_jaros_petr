package curves;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import model3d.Solid;
import transforms.Cubic;
import transforms.Point3D;

/*
*
* Třída pro vytvoření Ferguson curve
*
* */


public class FergusonCubic extends Solid {
    public FergusonCubic(double increment) {
        this.color = 16737894;
        this.name = "curve";
        Point3D p1 = new Point3D(1.0D, 1.0D, 1.0D);
        Point3D p2 = new Point3D(0.0D, 0.0D, 2.0D);
        Point3D p3 = new Point3D(-1.0D, -1.0D, 0.0D);
        Point3D p4 = new Point3D(0.0D, 1.0D, 1.0D);
        Cubic ferguson = new Cubic(Cubic.FERGUSON, p1, p2, p3, p4);
        List<Cubic> cubics = new ArrayList();
        cubics.add(ferguson);
        Point3D p5 = new Point3D(1.0D, 3.0D, 2.0D);
        Point3D p6 = new Point3D(0.0D, -1.0D, 0.0D);
        Point3D p7 = new Point3D(-1.0D, -1.0D, -1.0D);
        cubics.add(new Cubic(Cubic.FERGUSON, p4, p5, p6, p7));
        Point3D p8 = new Point3D(-1.0D, 0.0D, -2.0D);
        Point3D p9 = new Point3D(0.0D, -1.0D, -1.0D);
        cubics.add(new Cubic(Cubic.FERGUSON, p7, p8, p9, p7));
        Iterator var14 = cubics.iterator();

        while(var14.hasNext()) {
            Cubic c = (Cubic)var14.next();
            double lastParameterValue = 0.0D;

            for(double t = 0.0D; t <= 1.0D; t += increment) {
                Point3D computed = c.compute(t);
                this.vertexBuffer.add(computed);
                lastParameterValue = t;
            }

            if (lastParameterValue != 1.0D) {
                this.vertexBuffer.add(c.compute(1.0D));
            }

            for(int i = 1; i < this.getVertexBuffer().size(); ++i) {
                this.indexBuffer.add(i - 1);
                this.indexBuffer.add(i);
            }
        }

    }
}