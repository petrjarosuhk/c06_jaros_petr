package view;

import java.awt.Component;
import javax.swing.JFrame;

/*
*
* Třída pro vytvoření okna
*
* */


public class Frame extends JFrame {
    private final Panel panel;

    public Frame() {
        this.setDefaultCloseOperation(3);
        this.setTitle("UHK FIM Petr Jaroš");
        this.panel = new Panel(this);
        this.add(this.panel, "Center");
        this.setVisible(true);
        this.pack();
        this.setLocationRelativeTo((Component)null);
        this.panel.setFocusable(true);
        this.panel.grabFocus();
    }

    public Panel getPanel() {
        return this.panel;
    }
}
