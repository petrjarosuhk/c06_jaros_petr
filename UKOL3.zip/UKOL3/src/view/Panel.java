package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JToolBar;
import rasterize.Raster;
import rasterize.RasterBufferedImage;

/*
* Třída pro nadefování GUI a ovládání.
*
* */


public class Panel extends JPanel {
    private static final int FPS =  50;
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    Frame frame;
    JSlider sliderPosition;
    JSlider sliderRotation;
    JSlider sliderSize;
    private RasterBufferedImage raster;
    private JToolBar toolBarMenu;
    private JToolBar toolBarSliders;
    private JCheckBox cboxCube;
    private JCheckBox cboxPyramid;
    private JRadioButton rbnBezier;
    private JRadioButton rbnFerguson;
    private JRadioButton rbnCoons;
    private JCheckBox cboxOctahedron;
    private JCheckBox cboxCurve;
    private JRadioButton rbnOrtogonal;
    private JRadioButton rbnPerspective;
    private ButtonGroup grpCurves;
    private JButton btnApply;
    private JButton btnReset;
    private JComboBox cb;
    private String selectedAxis = "x";
    private JLabel lblSelectedObject;

    Panel(Frame frame) {
        this.frame = frame;
        this.setPreferredSize(new Dimension(800, 600));
        this.raster = new RasterBufferedImage(800, 600);
        this.raster.setClearColor(Color.BLACK.getRGB());
        this.setLoop();
        this.initToolbar();
        this.initToolbarSliders();
    }

    private void initToolbar() {
        this.toolBarMenu = new JToolBar();
        this.toolBarMenu.setFloatable(false);
        this.toolBarMenu.setFocusable(false);
        this.frame.add(this.toolBarMenu, "North");
        JSeparator separator1 = new JSeparator(1);
        separator1.setBackground(Color.gray);
        this.toolBarMenu.add(separator1);
        separator1.setForeground(Color.gray.darker());
        this.cboxCube = new JCheckBox("Cube");
        this.toolBarMenu.add(this.cboxCube);
        this.cboxCube.setSelected(true);
        this.cboxCube.setFocusable(false);
        this.cboxPyramid = new JCheckBox("Pyramid");
        this.toolBarMenu.add(this.cboxPyramid);
        this.cboxPyramid.setFocusable(false);
        this.cboxOctahedron = new JCheckBox("Octahedron");
        this.toolBarMenu.add(this.cboxOctahedron);
        this.cboxOctahedron.setFocusable(false);
        JSeparator separator2 = new JSeparator(1);
        separator2.setBackground(Color.gray);
        separator2.setForeground(Color.gray.darker());
        this.toolBarMenu.add(separator2);
        ButtonGroup grpView = new ButtonGroup();
        this.rbnPerspective = new JRadioButton("Perspective");
        grpView.add(this.rbnPerspective);
        this.rbnPerspective.setFocusable(false);
        this.rbnPerspective.setSelected(true);
        this.toolBarMenu.add(this.rbnPerspective);
        this.rbnOrtogonal = new JRadioButton("Orthographic");
        grpView.add(this.rbnOrtogonal);
        this.rbnOrtogonal.setFocusable(false);
        this.toolBarMenu.add(this.rbnOrtogonal);
        JSeparator separator3 = new JSeparator(1);
        separator3.setBackground(Color.gray);
        separator3.setForeground(Color.gray.darker());
        this.toolBarMenu.add(separator3);
        this.cboxCurve = new JCheckBox("Curve");
        this.toolBarMenu.add(this.cboxCurve);
        this.cboxCurve.setFocusable(false);
        this.cboxCurve.setSelected(true);
        this.grpCurves = new ButtonGroup();
        this.rbnFerguson = new JRadioButton("Ferguson");
        this.grpCurves.add(this.rbnFerguson);
        this.rbnFerguson.setSelected(true);
        this.rbnFerguson.setFocusable(false);
        this.toolBarMenu.add(this.rbnFerguson);
        this.rbnBezier = new JRadioButton("Bezier");
        this.grpCurves.add(this.rbnBezier);
        this.rbnBezier.setFocusable(false);
        this.toolBarMenu.add(this.rbnBezier);
        this.rbnCoons = new JRadioButton("Coons");
        this.grpCurves.add(this.rbnCoons);
        this.rbnCoons.setFocusable(false);
        this.toolBarMenu.add(this.rbnCoons);
        this.btnApply = new JButton("Apply");
        this.btnApply.setFocusable(false);
        this.btnApply.setBackground(Color.gray);
        this.toolBarMenu.add(this.btnApply);
        this.btnReset = new JButton("Reset");
        this.btnReset.setFocusable(false);
        this.btnReset.setBackground(Color.gray);
        this.toolBarMenu.add(this.btnReset);
    }

    private void initToolbarSliders() {
        this.toolBarSliders = new JToolBar();
        this.frame.add(this.toolBarSliders, "South");
        this.toolBarSliders.setFloatable(false);
        this.toolBarSliders.setFocusable(false);
        this.toolBarSliders.setPreferredSize(new Dimension(600, 30));
        String[] cbOptions = new String[]{"x", "y", "z"};
        this.cb = new JComboBox(cbOptions);
        JLabel posLabel = new JLabel("Translation");
        this.sliderPosition = new JSlider(-10, 10);
        this.sliderPosition.setValue(0);
        JLabel sizeLabel = new JLabel("Scaling");
        this.sliderSize = new JSlider(1, 4);
        this.sliderSize.setValue(1);
        JLabel rotLabel = new JLabel("Rotation");
        this.sliderRotation = new JSlider(-180, 180);
        this.sliderRotation.setValue(0);
        Dimension maxWidth = new Dimension(120, 30);
        this.sliderPosition.setPreferredSize(maxWidth);
        this.sliderSize.setPreferredSize(maxWidth);
        this.sliderRotation.setPreferredSize(maxWidth);
        this.cb.setMaximumSize(new Dimension(30, 30));
        this.toolBarSliders.add(this.cb);
        this.toolBarSliders.add(posLabel);
        this.toolBarSliders.add(this.sliderPosition);
        this.toolBarSliders.add(sizeLabel);
        this.toolBarSliders.add(this.sliderSize);
        this.toolBarSliders.add(rotLabel);
        this.toolBarSliders.add(this.sliderRotation);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.raster.repaint(g);
    }

    private void setLoop() {
        (new Timer()).schedule(new TimerTask() {
            public void run() {
                Panel.this.repaint();
            }
        }, 0L, 50L);
    }

    public Raster getRaster() {
        return this.raster;
    }

    public JCheckBox getCboxCube() {
        return this.cboxCube;
    }

    public JCheckBox getCboxPyramid() {
        return this.cboxPyramid;
    }

    public JRadioButton getRbnBezier() {
        return this.rbnBezier;
    }

    public JRadioButton getRbnFerguson() {
        return this.rbnFerguson;
    }

    public JCheckBox getCboxOctahedron() {
        return this.cboxOctahedron;
    }

    public JCheckBox getCboxCurve() {
        return this.cboxCurve;
    }

    public JRadioButton getRbnCoons() {
        return this.rbnCoons;
    }

    public JRadioButton getRbnPerspective() {
        return this.rbnPerspective;
    }

    public JRadioButton getRbnOrtogonal() {
        return this.rbnOrtogonal;
    }

    public JToolBar getToolBarMenu() {
        return this.toolBarMenu;
    }

    public JButton getBtnApply() {
        return this.btnApply;
    }

    public JButton getBtnReset() {
        return this.btnReset;
    }

    public JSlider getSliderPosition() {
        return this.sliderPosition;
    }

    public JSlider getSliderRotation() {
        return this.sliderRotation;
    }

    public JSlider getSliderSize() {
        return this.sliderSize;
    }

    public JComboBox getCb() {
        return this.cb;
    }
}
