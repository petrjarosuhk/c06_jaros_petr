package app;

import controller3d.*;
import view.Frame;

import javax.swing.*;
/*
* Třída pro spuštění celé Aplikace
* Tuto třídu prosím spusťě.
* */
public class AppStart {


    //metoda pro spuštění aplikace
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Frame frame = new Frame();
            frame.setResizable(false);
            new Controller3D(frame.getPanel());
            frame.setVisible(true);
        });
    }
}
