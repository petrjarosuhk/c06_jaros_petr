package rasterize;

import java.awt.Color;
import java.awt.Graphics;

import static java.lang.Math.round;
import static java.lang.Math.abs;

/*
*
* Díky teto tříde je možno linerasterizovat pomocí DDA algoritmu, který je zde použit
*
* */


public class LineRasterizerDDA extends LineRasterizer {
    public LineRasterizerDDA(Raster raster) {
        super(raster);
    }

    //metoda pro rasterizaci úsečky díky algoritmu DDA
    public void rasterize(int x1, int y1, int x2, int y2, Color color) {
        int dx = x2 - x1;
        int dy = y2 - y1;
        int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

        float Xinc = dx / (float) steps;
        float Yinc = dy / (float) steps;

        float X = x1;
        float Y = y1;
        for (int i = 0; i <= steps; i++)
        {
            raster.setPixel(round(X),round(Y), color);
            X += Xinc;
            Y += Yinc;
        }

    }

}
