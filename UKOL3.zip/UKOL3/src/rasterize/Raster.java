package rasterize;

import java.awt.*;
import java.awt.image.BufferedImage;

public interface Raster {
    void clear();

    void setClearColor(int var1);

    int getWidth();

    int getHeight();

    int getPixel(int var1, int var2);

    void setPixel(int var1, int var2, Color var3);

    BufferedImage getBufferedImage();
}
