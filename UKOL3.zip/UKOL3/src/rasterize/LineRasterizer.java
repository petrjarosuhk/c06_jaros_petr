package rasterize;

import java.awt.Color;

public abstract class LineRasterizer {
    Raster raster;
    Color color;

    public LineRasterizer(Raster raster) {
        this.raster = raster;
    }

    public final void setColor(Color color) {
        this.color = color;
    }

    public final void setColor(int color) {
        this.color = new Color(color);
    }

    public abstract void rasterize(int var1, int var2, int var3, int var4, Color var5);
}
