package rasterize;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;

public class RasterBufferedImage implements Raster {
    private final BufferedImage img;
    private int color;

    public RasterBufferedImage(int width, int height) {
        this.img = new BufferedImage(width, height, 1);
    }

    public void repaint(Graphics graphics) {
        graphics.drawImage(this.img, 0, 0, (ImageObserver)null);
    }


    public int getPixel(int x, int y) {
        return x > 0 && x < this.getWidth() && y > 0 && y < this.getHeight() ? this.img.getRGB(x, y) : Color.ORANGE.getRGB();
    }

    public void setPixel(int x, int y, Color color) {

        if (x > 0 && x < this.getWidth() && y > 0 && y < this.getHeight()) {


            this.img.setRGB(x, y,color.getRGB());
        }

    }

    public BufferedImage getBufferedImage() {
        return this.img;
    }

    public void clear() {
        Graphics g = this.img.getGraphics();
        g.setColor(new Color(this.color));
        g.fillRect(0, 0, this.img.getWidth(), this.img.getHeight());
    }

    public void setClearColor(int color) {
        this.color = color;
    }

    public int getWidth() {
        return this.img.getWidth();
    }

    public int getHeight() {
        return this.img.getHeight();
    }

}