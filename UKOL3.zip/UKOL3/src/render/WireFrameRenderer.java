package render;

import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import model3d.Scene;
import model3d.Solid;
import rasterize.LineRasterizerDDA;
import rasterize.Raster;
import transforms.Mat4;
import transforms.Point3D;
import transforms.Vec3D;

/*
*
* Třída pro render do obrazovky
* Linerasterizujeme pomocí algortmu typu DDA 
*
* */

public class WireFrameRenderer implements Renderer {
    private final Raster raster;
    private final LineRasterizerDDA lineRasterizerDDA;
    private Mat4 model;
    private Mat4 view;
    private Mat4 projection;
    private Mat4 matTransformObjects;
    private Solid objectToTransform;

    public WireFrameRenderer(Raster raster, Mat4 model, Mat4 view, Mat4 projection) {
        this.raster = raster;
        this.lineRasterizerDDA = new LineRasterizerDDA(raster);
        this.view = view;
        this.projection = projection;
        this.model = model;
    }

    //metoda pro vykreslení veškéré scény
    public void draw(Scene scene) {
        Iterator var2 = scene.getSolids().iterator();

        while(var2.hasNext()) {
            Solid solid = (Solid)var2.next();
            List<Point3D> vertexBuffer = solid.getVertexBuffer();
            List<Integer> indexBuffer = solid.getIndexBuffer();
            Color color = new Color(solid.getColor());

            for(int i = 0; i < indexBuffer.size(); i += 2) {
                Integer index1 = (Integer)indexBuffer.get(i);
                Integer index2 = (Integer)indexBuffer.get(i + 1);
                Point3D p1 = (Point3D)vertexBuffer.get(index1);
                Point3D p2 = (Point3D)vertexBuffer.get(index2);
                if (solid.equals(this.objectToTransform)) {
                    p1 = p1.mul(this.matTransformObjects);
                    p2 = p2.mul(this.matTransformObjects);
                }

                this.transformLine(p1, p2, color, solid.isAxis());
            }
        }

    }

    //metoda pro translaci dané liny
    private void transformLine(Point3D a, Point3D b, Color color, boolean isAxis) {
        Mat4 transformationMatrix = this.model.mul(this.view).mul(this.projection);
        a = a.mul(transformationMatrix);
        b = b.mul(transformationMatrix);
        if (!isAxis) {
            if (this.clip(a)) {
                return;
            }

            if (this.clip(a)) {
                return;
            }
        }

        Optional<Vec3D> dehomogA = a.dehomog();
        Optional<Vec3D> dehomogB = b.dehomog();
        if (dehomogA.isPresent() && dehomogB.isPresent()) {
            Vec3D v1 = (Vec3D)dehomogA.get();
            Vec3D v2 = (Vec3D)dehomogB.get();
            v1 = this.transformToWindow(v1);
            v2 = this.transformToWindow(v2);
            this.lineRasterizerDDA.rasterize((int)Math.round(v1.getX()), (int)Math.round(v1.getY()), (int)Math.round(v2.getX()), (int)Math.round(v2.getY()), color);
        }
    }

    //metoda transformace do okna
    private Vec3D transformToWindow(Vec3D v) {
        return v.mul(new Vec3D(1.0D, -1.0D, 1.0D)).add(new Vec3D(1.0D, 1.0D, 0.0D)).mul(new Vec3D((double)this.raster.getWidth() / 2.0D, (double)this.raster.getHeight() / 2.0D, 1.0D));
    }

    //jestli se bude nebo nebude clipovat, vrátí hodnotu true nebo false
    private boolean clip(Point3D p) {
        double x = p.getX();
        double y = p.getY();
        double z = p.getZ();
        double w = p.getW();
        return !(-w <= x) || !(x <= w) || !(-w <= y) || !(y <= w) || !(0.0D <= z) || !(z <= w);
    }

    public void setModel(Mat4 model) {
        this.model = model;
    }

    public void setView(Mat4 view) {
        this.view = view;
    }

    public void setProjection(Mat4 projection) {
        this.projection = projection;
    }

    public void setMatTransformObjects(Mat4 matTransformObjects) {
        this.matTransformObjects = matTransformObjects;
    }

    public Solid getObjectToTransform() {
        return this.objectToTransform;
    }

    public void setObjectToTransform(Solid objectToTransform) {
        this.objectToTransform = objectToTransform;
    }
}