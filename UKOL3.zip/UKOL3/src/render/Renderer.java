package render;

import model3d.Scene;
import model3d.Solid;
import transforms.Mat4;

public interface Renderer {
    void draw(Scene var1);

    void setModel(Mat4 var1);

    void setView(Mat4 var1);

    void setProjection(Mat4 var1);

    void setMatTransformObjects(Mat4 var1);

    Solid getObjectToTransform();

    void setObjectToTransform(Solid var1);
}
